# Decision Intelligence Lab

A starter web app for a professional data-science portfolio. It begins with a pharmacy stockout risk demonstration and includes spreadsheet exploration and model evaluation.

## Important
- The built-in demo model uses **synthetic data**. Its risk score is not validated against real pharmacy records.
- Do not use demo predictions alone for purchasing or patient-care decisions.
- Do not upload patient-identifying or confidential information.
- Generative AI is planned but not connected in this starter version.

## Run in Google Colab
1. Open Google Colab: https://colab.research.google.com/
2. Create a new notebook.
3. Upload `app.py` and `requirements.txt` from this project (or upload the ZIP and extract it).
4. Run this cell:

```python
!pip -q install -r requirements.txt
```

5. Run this cell:

```python
!python app.py
```

Gradio will print a local link and may print a share link depending on its launch settings. For Colab, a notebook-native launch with `share=True` is usually more convenient. If the app does not produce a public share link, use the Hugging Face Spaces deployment steps below.

## Recommended: deploy a public demo with Hugging Face Spaces
1. Create an account at https://huggingface.co/
2. Create a new Space and choose **Gradio** as the SDK.
3. Upload `app.py` and `requirements.txt` to the Space repository.
4. The Space will install dependencies and build the app.
5. Share the Space URL in your portfolio and GitHub README.

## GitHub setup
1. Create a public repository named `decision-intelligence-lab`.
2. Add `app.py`, `requirements.txt`, and this `README.md`.
3. Commit the files.
4. Add your deployed demo URL near the top of the README when it is available.

## Features
- Pharmacy risk estimate using an illustrative Random Forest model.
- Days-of-stock-cover calculation and illustrative reorder quantity.
- CSV/Excel upload, preview, missing-cell count, and numeric correlation heatmap.
- Training and holdout evaluation for a labeled dataset.

## Required training columns
`Current_Stock`, `Avg_Daily_Sales`, `Lead_Time_Days`, `Lead_Time_Variability`, `Supplier_Reliability`, `Pending_Order_Units`, `Days_Since_Restock`, `Seasonal_Index`, `Promotion_Active`, `Medicine_Category`, `Supplier`, `Stockout_Risk`.

## Next improvements
- Replace synthetic training labels with validated, permissioned historical data.
- Add time-aware validation and compare baseline, Logistic Regression, Random Forest, and gradient-boosted models.
- Add configurable reorder policies and a human approval workflow.
- Add secure backend/API integration for generative AI; never hard-code API keys in the frontend or GitHub.
