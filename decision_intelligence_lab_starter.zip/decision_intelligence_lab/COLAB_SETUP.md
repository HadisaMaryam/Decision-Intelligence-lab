# Colab notebook cells for Decision Intelligence Lab

## Cell 1 — Install packages
```python
!pip -q install gradio pandas numpy plotly scikit-learn openpyxl
```

## Cell 2 — Upload app.py
```python
from google.colab import files
uploaded = files.upload()  # Select app.py
```

## Cell 3 — Launch a shareable demo
```python
# In app.py, change the final line from demo.launch() to demo.launch(share=True)
# Then run:
!python app.py
```

If you prefer not to edit the file manually, use this cell to make a Colab-friendly copy:
```python
from pathlib import Path
p = Path("app.py")
code = p.read_text()
code = code.replace("demo.launch()", "demo.launch(share=True)")
p.write_text(code)
!python app.py
```

Keep the Colab session running while testing the temporary share link. Temporary links are not permanent hosting. Use Hugging Face Spaces for a more persistent public demo.
