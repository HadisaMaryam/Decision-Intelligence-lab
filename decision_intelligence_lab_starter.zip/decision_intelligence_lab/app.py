import gradio as gr
import pandas as pd
import numpy as np
import plotly.express as px
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix

APP_TITLE = "Decision Intelligence Lab"

NUMERIC_FEATURES = [
    "Current_Stock", "Avg_Daily_Sales", "Lead_Time_Days",
    "Lead_Time_Variability", "Supplier_Reliability",
    "Pending_Order_Units", "Days_Since_Restock", "Seasonal_Index",
    "Promotion_Active"
]
CATEGORICAL_FEATURES = ["Medicine_Category", "Supplier"]
FEATURES = NUMERIC_FEATURES + CATEGORICAL_FEATURES

def make_demo_data(n=1500, seed=42):
    """Create clearly labeled synthetic records for a demo; not real pharmacy data."""
    rng = np.random.default_rng(seed)
    categories = np.array(["Diabetes", "Cardiovascular", "Antibiotic", "Pain Relief",
                           "Respiratory", "Gastrointestinal", "Vitamins", "Dermatology"])
    suppliers = np.array(["Supplier A", "Supplier B", "Supplier C", "Supplier D", "Supplier E"])
    category = rng.choice(categories, n)
    supplier = rng.choice(suppliers, n)
    avg_sales = np.maximum(0.2, rng.gamma(2.3, 2.0, n))
    current_stock = rng.integers(0, 180, n)
    lead_time = rng.integers(1, 10, n)
    lead_var = rng.uniform(0, 4, n)
    reliability = rng.uniform(0.55, 1.0, n)
    pending = rng.integers(0, 100, n)
    since_restock = rng.integers(0, 45, n)
    seasonal = rng.uniform(0.65, 1.8, n)
    promo = rng.binomial(1, 0.18, n)
    expected_demand = avg_sales * seasonal * (1 + 0.35 * promo)
    cover = current_stock / np.maximum(expected_demand, 0.1)
    effective_lead = lead_time + lead_var + (1 - reliability) * 5
    # Synthetic label: risk when available cover is low relative to replenishment time.
    risk_score = (effective_lead - cover) + 0.025 * since_restock - 0.018 * pending
    probability = 1 / (1 + np.exp(-np.clip(risk_score, -10, 10)))
    risk = (rng.random(n) < probability).astype(int)
    df = pd.DataFrame({
        "Current_Stock": current_stock,
        "Avg_Daily_Sales": np.round(avg_sales, 2),
        "Lead_Time_Days": lead_time,
        "Lead_Time_Variability": np.round(lead_var, 2),
        "Supplier_Reliability": np.round(reliability, 2),
        "Pending_Order_Units": pending,
        "Days_Since_Restock": since_restock,
        "Seasonal_Index": np.round(seasonal, 2),
        "Promotion_Active": promo,
        "Medicine_Category": category,
        "Supplier": supplier,
        "Stockout_Risk": risk
    })
    return df

def prepare_model(df):
    usable = df.copy()
    if "Stockout_Risk" not in usable.columns:
        raise ValueError("The dataset must contain a Stockout_Risk column (0 or 1) to train a model.")
    missing = [c for c in FEATURES if c not in usable.columns]
    if missing:
        raise ValueError("Missing required columns: " + ", ".join(missing))
    usable = usable[FEATURES + ["Stockout_Risk"]].copy()
    usable["Stockout_Risk"] = pd.to_numeric(usable["Stockout_Risk"], errors="coerce")
    usable = usable.dropna(subset=["Stockout_Risk"])
    usable["Stockout_Risk"] = usable["Stockout_Risk"].astype(int)
    usable = usable[usable["Stockout_Risk"].isin([0, 1])]
    if len(usable) < 20 or usable["Stockout_Risk"].nunique() < 2:
        raise ValueError("Please provide at least 20 usable rows and both risk classes (0 and 1).")
    for col in NUMERIC_FEATURES:
        usable[col] = pd.to_numeric(usable[col], errors="coerce")
    numeric_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])
    categorical_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore"))
    ])
    preprocess = ColumnTransformer([
        ("num", numeric_pipe, NUMERIC_FEATURES),
        ("cat", categorical_pipe, CATEGORICAL_FEATURES)
    ])
    model = Pipeline([
        ("preprocess", preprocess),
        ("classifier", RandomForestClassifier(
            n_estimators=180, max_depth=10, class_weight="balanced",
            random_state=42
        ))
    ])
    X_train, X_test, y_train, y_test = train_test_split(
        usable[FEATURES], usable["Stockout_Risk"], test_size=0.2,
        random_state=42, stratify=usable["Stockout_Risk"]
    )
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    metrics = {
        "Test rows": len(y_test),
        "Accuracy": round(accuracy_score(y_test, pred), 3),
        "Precision": round(precision_score(y_test, pred, zero_division=0), 3),
        "Recall": round(recall_score(y_test, pred, zero_division=0), 3),
        "F1 score": round(f1_score(y_test, pred, zero_division=0), 3)
    }
    return model, metrics, usable

def make_overview(df):
    if df is None or df.empty:
        return "No data available yet."
    rows = len(df)
    risk_count = int(df["Stockout_Risk"].sum()) if "Stockout_Risk" in df else 0
    risk_pct = risk_count / rows * 100 if rows else 0
    return (
        f"### Dataset overview\n"
        f"- **Records:** {rows:,}\n"
        f"- **Columns:** {len(df.columns)}\n"
        f"- **Records labeled high risk (0/1 target):** {risk_count:,} ({risk_pct:.1f}%)\n"
        f"- **Data status:** {'Synthetic demonstration data' if df.attrs.get('synthetic', False) else 'Uploaded data — verify its source and quality'}"
    )

def risk_prediction(stock, sales, lead, variability, reliability, pending, since, seasonal, promo, category, supplier):
    if sales <= 0:
        return "Enter average daily sales greater than zero.", None
    cover = float(stock) / max(float(sales) * float(seasonal) * (1 + 0.35 * int(promo)), 0.1)
    effective_lead = float(lead) + float(variability) + (1 - float(reliability)) * 5
    # Use a trained demo model on the synthetic training data.
    df = make_demo_data(1500)
    model, _, _ = prepare_model(df)
    row = pd.DataFrame([{
        "Current_Stock": stock, "Avg_Daily_Sales": sales,
        "Lead_Time_Days": lead, "Lead_Time_Variability": variability,
        "Supplier_Reliability": reliability, "Pending_Order_Units": pending,
        "Days_Since_Restock": since, "Seasonal_Index": seasonal,
        "Promotion_Active": promo, "Medicine_Category": category,
        "Supplier": supplier
    }])
    probability = float(model.predict_proba(row)[0][1])
    level = "HIGH" if probability >= 0.65 else ("MEDIUM" if probability >= 0.35 else "LOW")
    reorder_point = float(sales) * float(seasonal) * (1 + 0.35 * int(promo)) * effective_lead
    suggested_order = max(0, int(np.ceil(reorder_point - float(stock) - float(pending))))
    result = (
        f"## {level} stockout risk\n"
        f"**Demo model risk estimate:** {probability:.1%}\n\n"
        f"- **Estimated days of stock cover:** {cover:.1f} days\n"
        f"- **Estimated replenishment window:** {effective_lead:.1f} days (includes variability and reliability adjustment)\n"
        f"- **Illustrative reorder quantity:** {suggested_order} units\n\n"
        f"**Interpretation:** {'Review this item promptly and confirm supplier lead time and demand.' if level == 'HIGH' else 'Monitor demand and verify the next delivery date.' if level == 'MEDIUM' else 'Current inputs suggest lower risk, but continue routine monitoring.'}\n\n"
        f"*Educational demonstration only. The model is trained on synthetic data, not validated pharmacy records. Do not use this output alone for medicine purchasing or patient-care decisions.*"
    )
    return result, probability

def analyze_upload(file):
    if file is None:
        return "Upload a CSV or Excel file to begin.", None, None
    try:
        path = file.name
        if path.lower().endswith(".csv"):
            df = pd.read_csv(path)
        else:
            df = pd.read_excel(path)
        overview = (
            f"### File loaded successfully\n"
            f"- **Rows:** {len(df):,}\n- **Columns:** {len(df.columns)}\n"
            f"- **Missing cells:** {int(df.isna().sum().sum()):,}\n\n"
            f"**Columns detected:** {', '.join(map(str, df.columns[:25]))}"
        )
        preview = df.head(15)
        numeric = df.select_dtypes(include=np.number)
        if numeric.shape[1] >= 1:
            corr = numeric.corr(numeric_only=True).reset_index().rename(columns={"index":"Variable"})
            fig = px.imshow(numeric.corr(numeric_only=True), text_auto=".2f",
                            title="Numeric variable correlation (exploratory)",
                            aspect="auto", color_continuous_scale="RdBu_r", zmin=-1, zmax=1)
        else:
            fig = None
        return overview, preview, fig
    except Exception as e:
        return f"Could not read file: {e}", None, None

def train_uploaded(file):
    if file is None:
        return "Upload a CSV or Excel file containing the required columns.", None
    try:
        df = pd.read_csv(file.name) if file.name.lower().endswith(".csv") else pd.read_excel(file.name)
        model, metrics, usable = prepare_model(df)
        return (
            "### Training complete\n"
            + "\n".join([f"- **{k}:** {v}" for k, v in metrics.items()])
            + "\n\n*These are holdout metrics for the uploaded dataset. Check for leakage, class imbalance, and representative data before trusting the model.*",
            usable.head(15)
        )
    except Exception as e:
        return f"**Training could not be completed:** {e}", None

with gr.Blocks(theme=gr.themes.Soft(primary_hue="blue", secondary_hue="slate"),
               title=APP_TITLE, fill_width=True) as demo:
    gr.Markdown(
        "# Decision Intelligence Lab\n"
        "### Predict risks. Understand data. Make better decisions.\n"
        "A practical analytics workspace combining machine learning, mathematics, and business decision support."
    )
    gr.Markdown(
        "> **Prototype notice:** Demo predictions use synthetic training data. This app is a learning and portfolio prototype, not a clinically validated or production inventory system."
    )
    with gr.Tabs():
        with gr.Tab("Pharmacy Risk Predictor"):
            gr.Markdown("Enter an example inventory record. Stock cover is compared with estimated replenishment time.")
            with gr.Row():
                with gr.Column():
                    stock = gr.Slider(0, 300, value=25, step=1, label="Current stock (units)")
                    sales = gr.Number(value=8, label="Average daily sales (units/day)")
                    lead = gr.Slider(1, 30, value=5, step=1, label="Supplier lead time (days)")
                    variability = gr.Slider(0, 10, value=2, step=0.5, label="Lead-time variability (days)")
                    reliability = gr.Slider(0.5, 1, value=0.85, step=0.01, label="Supplier reliability (0.5–1.0)")
                    pending = gr.Number(value=10, label="Pending order units")
                with gr.Column():
                    since = gr.Slider(0, 90, value=12, step=1, label="Days since restock")
                    seasonal = gr.Slider(0.5, 2.5, value=1, step=0.05, label="Seasonal demand index")
                    promo = gr.Checkbox(value=False, label="Promotion active")
                    category = gr.Dropdown(["Diabetes", "Cardiovascular", "Antibiotic", "Pain Relief", "Respiratory", "Gastrointestinal", "Vitamins", "Dermatology"], value="Diabetes", label="Medicine category")
                    supplier = gr.Dropdown(["Supplier A", "Supplier B", "Supplier C", "Supplier D", "Supplier E"], value="Supplier A", label="Supplier")
                    predict_btn = gr.Button("Estimate stockout risk", variant="primary")
            prediction = gr.Markdown()
            with gr.Accordion("How this works", open=False):
                gr.Markdown(
                    "- **Days of cover** = current stock ÷ expected daily demand.\n"
                    "- Expected demand adjusts average daily sales for seasonality and an optional promotion.\n"
                    "- The example model is a Random Forest trained on generated synthetic data.\n"
                    "- Risk levels are illustrative thresholds, not validated clinical or purchasing rules."
                )
            predict_btn.click(risk_prediction,
                inputs=[stock, sales, lead, variability, reliability, pending, since, seasonal, promo, category, supplier],
                outputs=[prediction, gr.Number(visible=False)])
        with gr.Tab("Data Studio"):
            gr.Markdown("Upload a CSV or Excel file for a quick exploratory overview. Your file should not contain patient-identifying information.")
            upload = gr.File(label="Upload CSV or Excel", file_types=[".csv", ".xlsx", ".xls"])
            analyze_btn = gr.Button("Analyze file", variant="primary")
            overview = gr.Markdown()
            preview = gr.Dataframe(label="First 15 rows", interactive=False)
            chart = gr.Plot(label="Correlation heatmap")
            analyze_btn.click(analyze_upload, inputs=upload, outputs=[overview, preview, chart])
        with gr.Tab("Train & Evaluate"):
            gr.Markdown(
                "Train a Random Forest using a labeled dataset. Required target: `Stockout_Risk` (0 or 1). "
                "Required features: `Current_Stock`, `Avg_Daily_Sales`, `Lead_Time_Days`, `Lead_Time_Variability`, "
                "`Supplier_Reliability`, `Pending_Order_Units`, `Days_Since_Restock`, `Seasonal_Index`, "
                "`Promotion_Active`, `Medicine_Category`, and `Supplier`."
            )
            train_file = gr.File(label="Upload labeled training data", file_types=[".csv", ".xlsx", ".xls"])
            train_btn = gr.Button("Train and evaluate", variant="primary")
            train_output = gr.Markdown()
            train_preview = gr.Dataframe(label="Rows used (preview)", interactive=False)
            train_btn.click(train_uploaded, inputs=train_file, outputs=[train_output, train_preview])
        with gr.Tab("About the Lab"):
            gr.Markdown(
                "## What this prototype demonstrates\n"
                "- **Machine Learning:** classification and evaluation metrics.\n"
                "- **Mathematics:** ratios, demand estimation, risk thresholds, and optimization foundations.\n"
                "- **Data analytics:** file upload, previews, missing-value checks, and correlations.\n"
                "- **Business thinking:** turning model output into a decision-support workflow.\n\n"
                "## Roadmap\n"
                "1. Validate with real, permissioned and anonymized inventory data.\n"
                "2. Add demand forecasting and configurable reorder policies.\n"
                "3. Add traffic safety analytics using a separate dataset.\n"
                "4. Add generative-AI explanations through a secured API integration.\n"
                "5. Add user accounts, audit logs, database storage, and monitoring only when needed."
            )
    gr.Markdown("---\nBuilt as a learning and portfolio prototype. Predictions should be reviewed by a qualified human decision-maker.")

if __name__ == "__main__":
    demo.launch()
